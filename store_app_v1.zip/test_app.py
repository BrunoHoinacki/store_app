from app import create_app, db

print("Teste de inicialização")
app = create_app()

with app.app_context():
    print("Testando conexão com banco de dados...")
    try:
        db.create_all()
        print("Banco de dados criado com sucesso!")
    except Exception as e:
        print(f"Erro ao criar banco de dados: {e}") 