from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_user, logout_user, login_required, current_user
from app.models import User, Product, Category, Sale, SaleItem
from app.forms import LoginForm, ProductForm, SaleForm, CategoryForm
from app import db
from datetime import datetime, timedelta
from sqlalchemy import func

# Create blueprints
main = Blueprint('main', __name__)
auth = Blueprint('auth', __name__)
products = Blueprint('products', __name__)
sales = Blueprint('sales', __name__)
categories = Blueprint('categories', __name__)
finance = Blueprint('finance', __name__)

# Auth routes
@auth.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('main.dashboard'))
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user and user.check_password(form.password.data):
            login_user(user)
            return redirect(url_for('main.dashboard'))
        flash('Usuário ou senha inválidos')
    return render_template('login.html', form=form)

@auth.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('auth.login'))

# Main routes
@main.route('/')
@main.route('/dashboard')
@login_required
def dashboard():
    products_count = Product.query.count()
    low_stock = Product.query.filter(Product.stock < 10).count()
    recent_sales = Sale.query.order_by(Sale.date.desc()).limit(5).all()
    return render_template('dashboard.html', 
                         products_count=products_count,
                         low_stock=low_stock,
                         recent_sales=recent_sales)

# Product routes
@products.route('/products')
@login_required
def product_list():
    products = Product.query.all()
    return render_template('products/list.html', products=products)

@products.route('/products/add', methods=['GET', 'POST'])
@login_required
def add_product():
    form = ProductForm()
    form.category_id.choices = [(c.id, c.name) for c in Category.query.all()]
    
    if form.validate_on_submit():
        product = Product(
            name=form.name.data,
            description=form.description.data,
            cost_price=form.cost_price.data,
            sale_price=form.sale_price.data,
            stock=form.stock.data,
            category_id=form.category_id.data
        )
        db.session.add(product)
        db.session.commit()
        flash('Produto adicionado com sucesso')
        return redirect(url_for('products.product_list'))
    
    return render_template('products/add.html', form=form)

@products.route('/products/edit/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_product(id):
    product = Product.query.get_or_404(id)
    form = ProductForm(obj=product)
    form.category_id.choices = [(c.id, c.name) for c in Category.query.all()]
    
    if form.validate_on_submit():
        product.name = form.name.data
        product.description = form.description.data
        product.cost_price = form.cost_price.data
        product.sale_price = form.sale_price.data
        product.stock = form.stock.data
        product.category_id = form.category_id.data
        
        db.session.commit()
        flash('Produto atualizado com sucesso')
        return redirect(url_for('products.product_list'))
    
    return render_template('products/edit.html', form=form, product=product)

@products.route('/products/delete/<int:id>', methods=['POST'])
@login_required
def delete_product(id):
    product = Product.query.get_or_404(id)
    db.session.delete(product)
    db.session.commit()
    flash('Produto excluído com sucesso')
    return redirect(url_for('products.product_list'))

@products.route('/products/adjust-stock/<int:id>', methods=['POST'])
@login_required
def adjust_stock(id):
    product = Product.query.get_or_404(id)
    try:
        adjustment = int(request.form.get('adjustment', 0))
        if adjustment != 0:
            new_stock = product.stock + adjustment
            if new_stock < 0:
                flash('Erro: Estoque não pode ser negativo')
            else:
                product.stock = new_stock
                db.session.commit()
                flash(f'Estoque atualizado com sucesso. Novo estoque: {new_stock}')
    except ValueError:
        flash('Erro: Valor inválido')
    return redirect(url_for('products.product_list'))

# Sales routes
@sales.route('/sales/new', methods=['GET', 'POST'])
@login_required
def new_sale():
    form = SaleForm()
    # Busca todos os produtos para a lista inicial
    products = Product.query.order_by(Product.name).all()
    
    if form.validate_on_submit():
        product = Product.query.get(form.product_id.data)
        if product.stock >= form.quantity.data:
            # Calcula o subtotal
            subtotal = product.sale_price * form.quantity.data
            
            # Calcula juros se aplicável
            total_amount = subtotal
            if form.has_interest.data and form.interest_rate.data > 0:
                interest = (form.interest_rate.data / 100) * subtotal
                total_amount = subtotal + interest
            
            sale = Sale(
                payment_method=form.payment_method.data,
                installments=form.installments.data,
                has_interest=form.has_interest.data,
                interest_rate=form.interest_rate.data if form.has_interest.data else 0,
                subtotal=subtotal,
                total_amount=total_amount,
                notes=form.notes.data,
                date=datetime.now()
            )
            
            sale_item = SaleItem(
                product=product,
                quantity=form.quantity.data,
                price=product.sale_price
            )
            
            product.stock -= form.quantity.data
            sale.items.append(sale_item)
            
            try:
                db.session.add(sale)
                db.session.commit()
                print(f"Venda {sale.id} salva com sucesso: Data {sale.date}, Valor {sale.total_amount}")
                flash('Venda realizada com sucesso')
                return redirect(url_for('sales.sale_history'))
            except Exception as e:
                db.session.rollback()
                print(f"Erro ao salvar venda: {str(e)}")
                flash('Erro ao salvar a venda')
        else:
            flash('Estoque insuficiente')
    
    return render_template('sales/new_sale.html', form=form, products=products)

@sales.route('/sales/history')
@login_required
def sale_history():
    sales = Sale.query.order_by(Sale.date.desc()).all()
    return render_template('sales/history.html', sales=sales)

@sales.route('/sales/cancel/<int:id>', methods=['POST'])
@login_required
def cancel_sale(id):
    sale = Sale.query.get_or_404(id)
    reason = request.form.get('reason', '')
    
    if sale.is_cancelled:
        flash('Esta venda já está cancelada')
        return redirect(url_for('sales.sale_history'))
    
    try:
        print(f"Iniciando cancelamento da venda {id}")
        # Guarda informações para verificação
        items_info = [(item.product.id, item.product.stock, item.quantity) 
                     for item in sale.items]
        
        sale.cancel(reason)
        
        # Verifica se os estoques foram atualizados corretamente
        for prod_id, old_stock, qty in items_info:
            product = Product.query.get(prod_id)
            expected_stock = old_stock + qty
            if product.stock != expected_stock:
                raise Exception(f"Erro na atualização do estoque do produto {product.name}")
        
        db.session.commit()
        print(f"Venda {id} cancelada com sucesso")
        flash('Venda cancelada com sucesso')
    except Exception as e:
        db.session.rollback()
        print(f"Erro ao cancelar venda: {str(e)}")
        flash(f'Erro ao cancelar venda: {str(e)}')
    
    return redirect(url_for('sales.sale_history'))

# Categories routes
@categories.route('/categories')
@login_required
def category_list():
    categories = Category.query.all()
    return render_template('categories/list.html', categories=categories)

@categories.route('/categories/add', methods=['GET', 'POST'])
@login_required
def add_category():
    form = CategoryForm()
    if form.validate_on_submit():
        category = Category(name=form.name.data)
        try:
            db.session.add(category)
            db.session.commit()
            flash('Categoria adicionada com sucesso')
            return redirect(url_for('categories.category_list'))
        except:
            db.session.rollback()
            flash('Erro: Esta categoria já existe')
    return render_template('categories/add.html', form=form)

@categories.route('/categories/edit/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_category(id):
    category = Category.query.get_or_404(id)
    form = CategoryForm(obj=category)
    
    if form.validate_on_submit():
        try:
            category.name = form.name.data
            db.session.commit()
            flash('Categoria atualizada com sucesso')
            return redirect(url_for('categories.category_list'))
        except:
            db.session.rollback()
            flash('Erro: Esta categoria já existe')
    
    return render_template('categories/edit.html', form=form, category=category)

@categories.route('/categories/delete/<int:id>', methods=['POST'])
@login_required
def delete_category(id):
    category = Category.query.get_or_404(id)
    if category.products:
        flash('Não é possível excluir: Existem produtos nesta categoria')
        return redirect(url_for('categories.category_list'))
    
    db.session.delete(category)
    db.session.commit()
    flash('Categoria excluída com sucesso')
    return redirect(url_for('categories.category_list'))

# Adicione esta nova rota junto com as outras rotas de vendas
@sales.route('/api/products')
@login_required
def get_products():
    search = request.args.get('search', '')
    products = Product.query.filter(
        Product.name.ilike(f'%{search}%')
    ).all()
    return jsonify([{
        'id': p.id,
        'text': f'{p.name} (R$ {p.sale_price:.2f}) - Estoque: {p.stock}',
        'stock': p.stock,
        'price': p.sale_price
    } for p in products])

@finance.route('/finance')
@login_required
def finance_dashboard():
    # Obtém o período do relatório (hoje, últimos 7 dias, últimos 30 dias ou personalizado)
    period = request.args.get('period', '30days')
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')

    if period == 'today':
        start_date = datetime.now().replace(hour=0, minute=0, second=0)
        end_date = datetime.now().replace(hour=23, minute=59, second=59)
    elif period == '7days':
        start_date = datetime.now() - timedelta(days=7)
        end_date = datetime.now().replace(hour=23, minute=59, second=59)
    elif period == '30days':
        start_date = datetime.now() - timedelta(days=30)
        end_date = datetime.now().replace(hour=23, minute=59, second=59)
    elif period == 'custom' and start_date and end_date:
        start_date = datetime.strptime(start_date, '%Y-%m-%d')
        end_date = datetime.strptime(end_date, '%Y-%m-%d').replace(hour=23, minute=59, second=59)
    elif period == 'all':
        # Busca todas as vendas sem filtro de data
        sales = Sale.query.order_by(Sale.date.desc()).all()
        if sales:
            start_date = sales[-1].date  # Data da venda mais antiga
            end_date = datetime.now().replace(hour=23, minute=59, second=59)
        else:
            start_date = datetime.now()
            end_date = datetime.now()
    else:
        start_date = datetime.now() - timedelta(days=30)
        end_date = datetime.now().replace(hour=23, minute=59, second=59)

    # Adicione um print para debug
    print(f"Buscando vendas de {start_date} até {end_date}")

    # Consulta as vendas do período (apenas vendas ativas)
    sales = Sale.query.filter(
        Sale.date.between(start_date, end_date),
        Sale.status == 'active'  # Adicione este filtro
    ).order_by(Sale.date.desc()).all()

    # Print para debug
    print(f"Encontradas {len(sales)} vendas")
    for sale in sales:
        print(f"Venda {sale.id}: Data {sale.date}, Valor {sale.total_amount}")

    # Calcula totais
    total_sales = sum(sale.total_amount for sale in sales)
    total_items = sum(item.quantity for sale in sales for item in sale.items)
    
    # Calcula custos e lucros
    total_cost = sum(item.quantity * item.product.cost_price for sale in sales for item in sale.items)
    total_profit = total_sales - total_cost
    
    # Agrupa vendas por método de pagamento
    payment_methods = {}
    for sale in sales:
        method = sale.payment_method
        if method not in payment_methods:
            payment_methods[method] = {'count': 0, 'total': 0}
        payment_methods[method]['count'] += 1
        payment_methods[method]['total'] += sale.total_amount

    # Produtos mais vendidos
    top_products = db.session.query(
        Product,
        func.sum(SaleItem.quantity).label('total_quantity'),
        func.sum(SaleItem.quantity * SaleItem.price).label('total_revenue')
    ).join(SaleItem).join(Sale).filter(
        Sale.date.between(start_date, end_date)
    ).group_by(Product).order_by(
        func.sum(SaleItem.quantity).desc()
    ).limit(5).all()

    return render_template('finance/dashboard.html',
        period=period,
        start_date=start_date,
        end_date=end_date,
        total_sales=total_sales,
        total_items=total_items,
        total_cost=total_cost,
        total_profit=total_profit,
        payment_methods=payment_methods,
        top_products=top_products,
        sales=sales
    ) 