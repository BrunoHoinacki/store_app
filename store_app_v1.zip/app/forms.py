from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, FloatField, IntegerField, SelectField, TextAreaField, BooleanField
from wtforms.validators import DataRequired, Length, NumberRange, ValidationError
from app.models import Product

class LoginForm(FlaskForm):
    username = StringField('Usuário', validators=[DataRequired()])
    password = PasswordField('Senha', validators=[DataRequired()])
    submit = SubmitField('Entrar')

class ProductForm(FlaskForm):
    name = StringField('Nome', validators=[DataRequired(), Length(max=100)])
    description = TextAreaField('Descrição')
    cost_price = FloatField('Preço de Custo', validators=[DataRequired(), NumberRange(min=0)])
    sale_price = FloatField('Preço de Venda', validators=[DataRequired(), NumberRange(min=0)])
    stock = IntegerField('Estoque', validators=[DataRequired(), NumberRange(min=0)])
    category_id = SelectField('Categoria', coerce=int, validators=[DataRequired()])
    submit = SubmitField('Salvar')

class SaleForm(FlaskForm):
    product_id = SelectField('Produto', coerce=int, choices=[], validate_choice=False)
    quantity = IntegerField('Quantidade', validators=[DataRequired(), NumberRange(min=1)])
    payment_method = SelectField('Forma de Pagamento', 
        choices=[
            ('money', 'Dinheiro'),
            ('credit', 'Cartão de Crédito'),
            ('debit', 'Cartão de Débito'),
            ('pix', 'PIX'),
            ('transfer', 'Transferência Bancária')
        ],
        validators=[DataRequired()]
    )
    installments = IntegerField('Número de Parcelas', default=1, validators=[NumberRange(min=1, max=12)])
    has_interest = BooleanField('Aplicar Juros')
    interest_rate = FloatField('Taxa de Juros (%)', default=0)
    notes = TextAreaField('Observações')
    submit = SubmitField('Finalizar Venda')

    def validate_installments(self, field):
        if self.payment_method.data != 'credit' and field.data > 1:
            raise ValidationError('Apenas vendas no cartão de crédito podem ser parceladas')

    def validate_product_id(self, field):
        if not field.data:
            raise ValidationError('Selecione um produto')
        product = Product.query.get(field.data)
        if not product:
            raise ValidationError('Produto inválido')

class CategoryForm(FlaskForm):
    name = StringField('Nome', validators=[DataRequired(), Length(max=64)])
    submit = SubmitField('Salvar') 