from app import create_app, db
from app.models import User, Category, Product
from datetime import datetime
import os

print("Iniciando script...")
print(f"Diretório atual: {os.getcwd()}")

app = create_app()

def init_db():
    """Inicializa o banco de dados com dados de teste"""
    print("Iniciando inicialização do banco...")
    with app.app_context():
        # Recria todas as tabelas
        print("Removendo tabelas existentes...")
        db.drop_all()
        print("Criando novas tabelas...")
        db.create_all()
        
        print("Criando usuário de teste...")
        # Cria usuário admin
        admin = User(username='admin')
        admin.set_password('admin')
        db.session.add(admin)
        
        print("Criando categorias...")
        # Cria categorias
        categories = [
            'Eletrônicos',
            'Alimentos',
            'Bebidas',
            'Roupas',
            'Calçados',
            'Acessórios',
            'Livros',
            'Papelaria',
            'Higiene',
            'Limpeza'
        ]
        
        category_objects = {}
        for cat_name in categories:
            cat = Category(name=cat_name)
            db.session.add(cat)
            category_objects[cat_name] = cat
        
        print("Criando produtos de exemplo...")
        # Cria alguns produtos de exemplo
        products = [
            {
                'name': 'Notebook Dell',
                'description': 'Notebook Dell Inspiron 15"',
                'cost_price': 2500.00,
                'sale_price': 3499.99,
                'stock': 5,
                'category': 'Eletrônicos'
            },
            {
                'name': 'Mouse Wireless',
                'description': 'Mouse sem fio',
                'cost_price': 25.00,
                'sale_price': 49.99,
                'stock': 20,
                'category': 'Eletrônicos'
            },
            {
                'name': 'Arroz 5kg',
                'description': 'Arroz tipo 1',
                'cost_price': 15.00,
                'sale_price': 22.90,
                'stock': 50,
                'category': 'Alimentos'
            },
            {
                'name': 'Feijão 1kg',
                'description': 'Feijão carioca',
                'cost_price': 5.00,
                'sale_price': 8.90,
                'stock': 40,
                'category': 'Alimentos'
            },
            {
                'name': 'Refrigerante 2L',
                'description': 'Refrigerante Cola',
                'cost_price': 4.00,
                'sale_price': 7.90,
                'stock': 30,
                'category': 'Bebidas'
            },
            {
                'name': 'Camiseta Básica',
                'description': 'Camiseta 100% algodão',
                'cost_price': 20.00,
                'sale_price': 39.90,
                'stock': 25,
                'category': 'Roupas'
            },
            {
                'name': 'Tênis Casual',
                'description': 'Tênis casual unissex',
                'cost_price': 50.00,
                'sale_price': 99.90,
                'stock': 15,
                'category': 'Calçados'
            },
            {
                'name': 'Detergente',
                'description': 'Detergente líquido 500ml',
                'cost_price': 1.50,
                'sale_price': 2.99,
                'stock': 100,
                'category': 'Limpeza'
            }
        ]
        
        for prod_data in products:
            product = Product(
                name=prod_data['name'],
                description=prod_data['description'],
                cost_price=prod_data['cost_price'],
                sale_price=prod_data['sale_price'],
                stock=prod_data['stock'],
                category=category_objects[prod_data['category']]
            )
            db.session.add(product)
        
        try:
            db.session.commit()
            print("Banco de dados inicializado com sucesso!")
            print("\nCredenciais de acesso:")
            print("Usuário: admin")
            print("Senha: admin123")
        except Exception as e:
            db.session.rollback()
            print(f"Erro ao inicializar banco de dados: {str(e)}")
            raise e

if __name__ == '__main__':
    print("Iniciando programa principal...")
    resposta = input("Isso irá apagar todos os dados existentes. Deseja continuar? (s/N): ")
    if resposta.lower() == 's':
        print("Iniciando inicialização...")
        try:
            init_db()
            print("\nIniciando aplicação...")
            app.run(debug=True)
        except Exception as e:
            print(f"Erro durante a inicialização: {str(e)}")
    else:
        print("Operação cancelada.") 